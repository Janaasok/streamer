const mongoose = require("mongoose");

const messageSchema = new mongoose.Schema({
  author: {
    type: mongoose.Types.ObjectId,
    ref: "User",
  },
  content: {
    type: String,
  },
  date: {
    type: Date,
  },
  type: { type: String, default: "DIRECT" },
  file: {
    name: String,
    type: String,
    url: String, // Store file link (if using cloud storage)
    data: String, // Base64 (if storing directly in DB, not recommended for large files)
  },
});

module.exports = mongoose.model("Message", messageSchema);
