const { v4: uuidv4 } = require("uuid");

const connectedUsers = new Map();
let activeRooms = [];
let gameRooms = [];

let io = null;

// Socket.IO server instance
const setSocketServerInstance = (ioInstance) => {
  io = ioInstance;
};

const getSocketServerInstance = () => {
  return io;
};

// Connected Users
const addNewConnectedUser = ({ socketId, userId }) => {
  connectedUsers.set(socketId, { userId });
};

const removeConnectedUser = (socketId) => {
  if (connectedUsers.has(socketId)) {
    connectedUsers.delete(socketId);
  }
};

const getActiveConnections = (userId) => {
  const activeConnections = [];
  connectedUsers.forEach((value, key) => {
    if (value.userId === userId) {
      activeConnections.push(key);
    }
  });
  return activeConnections;
};

const getOnlineUsers = () => {
  const onlineUsers = [];
  connectedUsers.forEach((value, key) => {
    onlineUsers.push({ socketId: key, userId: value.userId });
  });
  return onlineUsers;
};

// --- Active Rooms ---
const addNewActiveRoom = (userId, socketId) => {
  const newActiveRoom = {
    roomCreator: { userId, socketId },
    participants: [{ userId, socketId }],
    roomId: uuidv4(),
  };
  activeRooms = [...activeRooms, newActiveRoom];
  return newActiveRoom;
};

const getActiveRooms = () => {
  return [...activeRooms];
};

const getActiveRoom = (roomId) => {
  const activeRoom = activeRooms.find((room) => room.roomId === roomId);
  return activeRoom ? { ...activeRoom } : null;
};

const roomExists = (roomId) => {
  return activeRooms.some((room) => room.roomId === roomId);
};

const joinActiveRoom = (roomId, newParticipant) => {
  const room = activeRooms.find((room) => room.roomId === roomId);

  if (!room) {
    console.warn(`❗ Room not found: ${roomId}. Cannot join.`);
    return null;
  }

  // Remove old room entry
  activeRooms = activeRooms.filter((room) => room.roomId !== roomId);

  const updatedRoom = {
    ...room,
    participants: [...room.participants, newParticipant],
  };

  // Add updated room
  activeRooms.push(updatedRoom);

  return updatedRoom;
};

const leaveActiveRoom = (roomId, participantSocketId) => {
  const activeRoom = activeRooms.find((room) => room.roomId === roomId);

  if (activeRoom) {
    const updatedParticipants = activeRoom.participants.filter(
      (participant) => participant.socketId !== participantSocketId
    );

    activeRooms = activeRooms.filter((room) => room.roomId !== roomId);

    if (updatedParticipants.length > 0) {
      const updatedRoom = {
        ...activeRoom,
        participants: updatedParticipants,
      };
      activeRooms.push(updatedRoom);
    }
  }
};

// --- Game Rooms ---
const addGameRoom = (userId, socketId) => {
  const roomId = `game-room-${uuidv4()}`;
  const gameRoom = {
    roomId,
    players: [{ userId, socketId, score: 0 }],
    questions: [],
  };
  gameRooms.push(gameRoom);
  return gameRoom;
};

const joinGameRoom = (roomId, userId, socketId) => {
  const gameRoom = gameRooms.find((room) => room.roomId === roomId);
  if (gameRoom) {
    gameRoom.players.push({ userId, socketId, score: 0 });
    return gameRoom;
  }
  return null;
};

const leaveGameRoom = (userId, socketId) => {
  const gameRoom = gameRooms.find((room) =>
    room.players.some((player) => player.userId === userId)
  );
  if (gameRoom) {
    gameRoom.players = gameRoom.players.filter(
      (player) => player.userId !== userId
    );
    return gameRoom;
  }
  return null;
};

const getGameRoom = (roomId) => {
  return gameRooms.find((room) => room.roomId === roomId);
};

const updatePlayerScore = (roomId, userId, score) => {
  const gameRoom = gameRooms.find((room) => room.roomId === roomId);
  if (gameRoom) {
    const player = gameRoom.players.find((player) => player.userId === userId);
    if (player) {
      player.score += score;
    }
  }
};

// Export
module.exports = {
  setSocketServerInstance,
  getSocketServerInstance,
  addNewConnectedUser,
  removeConnectedUser,
  getActiveConnections,
  getOnlineUsers,

  addNewActiveRoom,
  getActiveRooms,
  getActiveRoom,
  joinActiveRoom,
  leaveActiveRoom,
  roomExists,

  addGameRoom,
  joinGameRoom,
  leaveGameRoom,
  getGameRoom,
  updatePlayerScore,
};
