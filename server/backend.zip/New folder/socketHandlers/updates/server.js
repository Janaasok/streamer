const updateServerPendingInvitations = (userId) => {
  // Emit an event to update the user's pending server invitations
};

const updateServerMembers = (serverId) => {
  // Emit an event to update the server's members list
};

module.exports = { updateServerPendingInvitations, updateServerMembers };