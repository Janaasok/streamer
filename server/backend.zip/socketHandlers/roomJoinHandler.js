const serverStore = require("../serverStore");
const roomsUpdates = require("./updates/rooms");

const roomJoinHandler = (socket, data) => {
  const { roomId } = data;

  const participantDetails = {
    userId: socket.user.userId,
    socketId: socket.id,
  };

  const roomDetails = serverStore.getActiveRoom(roomId);
  if (!roomDetails) {
    return socket.emit("error", { message: "Room not found." });
  }

  // Add participant
  const updatedRoom = serverStore.joinActiveRoom(roomId, participantDetails);

  // Join Socket.IO room
  socket.join(roomId);

  // Notify existing participants to prepare for WebRTC connection
  roomDetails.participants.forEach((participant) => {
    if (participant.socketId !== participantDetails.socketId) {
      socket.to(participant.socketId).emit("conn-prepare", {
        connUserSocketId: participantDetails.socketId,
      });
    }
  });

  // Notify the new participant about existing users
  roomDetails.participants.forEach((participant) => {
    socket.emit("conn-prepare", {
      connUserSocketId: participant.socketId,
    });
  });

  // Optionally send updated room details (participant list)
  roomsUpdates.updateRooms();

  console.log(`🔗 ${participantDetails.socketId} joined room ${roomId}`);
};

module.exports = roomJoinHandler;
