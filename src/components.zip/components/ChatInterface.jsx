import React, { useState } from 'react';
import { sendChatMessageToAI } from '../api';

function ChatInterface() {
  const [userInput, setUserInput] = useState('');
  const [chatLog, setChatLog] = useState([]);

  const handleSendMessage = async () => {
    if (userInput.trim()) {
      setChatLog([...chatLog, { user: 'You', message: userInput }]);
      setUserInput('');

      const aiResponseData = await sendChatMessageToAI(userInput);
      if (aiResponseData && aiResponseData.response) {
        setChatLog(prev => [...prev, { user: 'AI', message: aiResponseData.response }]);
      } else if (aiResponseData && aiResponseData.error) {
        setChatLog(prev => [...prev, { user: 'AI', message: 'Error getting AI response.' }]);
        console.error('Error from backend:', aiResponseData.exception);
      } else {
        setChatLog(prev => [...prev, { user: 'AI', message: 'No response from AI.' }]);
      }
    }
  };

  return (
    <div className="chat-container">
      <div className="chat-log">
        {chatLog.map((msg, index) => (
          <div key={index} className={`message ${msg.user.toLowerCase()}`}>
            <strong>{msg.user}:</strong> {msg.message}
          </div>
        ))}
      </div>
      <div className="chat-input">
        <input
          type="text"
          value={userInput}
          onChange={(e) => setUserInput(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
          placeholder="Type your message..."
        />
        <button onClick={handleSendMessage}>Send</button>
      </div>
    </div>
  );
}

export default ChatInterface;
