import React, { useState, useRef } from "react";
import { styled } from "@mui/system";
import { connect } from "react-redux";
import { sendDirectMessage } from "../socket/socketConnection.js";
import AttachFileIcon from "@mui/icons-material/AttachFile";
import InsertPhotoIcon from "@mui/icons-material/InsertPhoto";
import DescriptionIcon from "@mui/icons-material/Description";
import SendIcon from "@mui/icons-material/Send"; 

const MainContainer = styled("div")({
  height: "60px",
  width: "100%",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  gap: "10px",
  position: "relative",
  padding: "10px",
  backgroundColor: "#40444B",
  borderRadius: "8px",
});

const Input = styled("input")({
  backgroundColor: "#2f3136",
  width: "75%",
  height: "44px",
  color: "white",
  border: "none",
  borderRadius: "8px",
  fontSize: "14px",
  padding: "0 10px",
  outline: "none",
});

const FileInput = styled("input")({
  display: "none",
});

const UploadButton = styled("button")({
  background: "transparent",
  border: "none",
  cursor: "pointer",
  color: "white",
  fontSize: "18px", // Smaller icon
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  width: "30px",  // Thinner button
  height: "30px", // Shorter button
  padding: "5px",
});


const SendButton = styled("button")({
  background: "#5865F2",
  border: "none",
  cursor: "pointer",
  color: "white",
  borderRadius: "5px",
  width: "40px",  // Thinner button
  height: "40px", // Shorter button
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  transition: "background 0.2s",
  "&:hover": {
    background: "#4752C4",
  },
});

const PreviewContainer = styled("div")({
  position: "absolute",
  bottom: "70px",
  backgroundColor: "#2f3136",
  padding: "8px",
  borderRadius: "8px",
  display: "flex",
  alignItems: "center",
  gap: "10px",
  boxShadow: "0px 4px 8px rgba(0,0,0,0.2)",
});

const ImagePreview = styled("img")({
  width: "50px",
  height: "50px",
  borderRadius: "5px",
  objectFit: "cover",
});

const RemovePreviewButton = styled("button")({
  background: "#E74C3C",
  color: "white",
  border: "none",
  borderRadius: "5px",
  cursor: "pointer",
  padding: "5px 10px",
  fontSize: "12px",
  "&:hover": {
    background: "#C0392B",
  },
});

const NewMessageInput = ({ chosenChatDetails }) => {
  const [message, setMessage] = useState("");
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState("");
  const fileInputRef = useRef(null);

  const handleMessageValueChange = (event) => {
    setMessage(event.target.value);
  };

  const handleKeyPressed = (event) => {
    if (event.key === "Enter") {
      handleSendMessage();
    }
  };

  const handleSendMessage = () => {
    if (message.trim().length > 0 || selectedFile) {
      const messageData = {
        receiverUserId: chosenChatDetails.id,
        content: message,
      };

      if (selectedFile) {
        const reader = new FileReader();
        reader.readAsDataURL(selectedFile);
        reader.onloadend = () => {
          messageData.file = {
            name: selectedFile.name,
            type: selectedFile.type,
            data: reader.result, // Base64 encoded data
          };

          sendDirectMessage(messageData);
        };
      } else {
        sendDirectMessage(messageData);
      }

      setMessage("");
      setSelectedFile(null);
      setPreviewUrl("");
    }
  };

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      setSelectedFile(file);

      if (file.type.startsWith("image/")) {
        const reader = new FileReader();
        reader.onloadend = () => {
          setPreviewUrl(reader.result);
        };
        reader.readAsDataURL(file);
      } else {
        setPreviewUrl("");
      }
    }
  };

  const removePreview = () => {
    setSelectedFile(null);
    setPreviewUrl("");
  };

  const triggerFileInput = () => {
    fileInputRef.current.click();
  };

  return (
    <MainContainer>
      <UploadButton onClick={triggerFileInput}>
        <AttachFileIcon />
      </UploadButton>
      <FileInput type="file" ref={fileInputRef} onChange={handleFileUpload} />

      <Input
        placeholder={`Message ${chosenChatDetails.name}`}
        value={message}
        onChange={handleMessageValueChange}
        onKeyDown={handleKeyPressed}
      />

      <SendButton onClick={handleSendMessage}>
        <SendIcon />
      </SendButton>

      {selectedFile && (
        <PreviewContainer>
          {previewUrl ? (
            <ImagePreview src={previewUrl} alt="Preview" />
          ) : (
            <DescriptionIcon style={{ color: "white", fontSize: "30px" }} />
          )}
          <RemovePreviewButton onClick={removePreview}>Remove</RemovePreviewButton>
        </PreviewContainer>
      )}
    </MainContainer>
  );
};

const mapStoreStateToProps = ({ chat }) => {
  return {
    ...chat,
  };
};

export default connect(mapStoreStateToProps)(NewMessageInput);
