import React, { useEffect, useRef, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  socket,
  connectWithSocketServer,
  joinRoom,
  leaveRoom as leaveSocketRoom,
} from "../socket/socketConnection";

const emojis = ["👍", "😂", "❤️", "🔥", "👏"];

const StreamRoom = () => {
  const { serverId } = useParams();
  const navigate = useNavigate();
  const localCamRef = useRef(null);
  const localScreenRef = useRef(null);
  const remoteVideoRef = useRef(null);
  const peerConnectionRef = useRef(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [reactions, setReactions] = useState([]);
  const [micEnabled, setMicEnabled] = useState(true);
  const [camEnabled, setCamEnabled] = useState(true);
  const [isSharingScreen, setIsSharingScreen] = useState(false);

  const cameraStreamRef = useRef(null);
  const screenStreamRef = useRef(null);
  const [isInitiator, setIsInitiator] = useState(false);

  useEffect(() => {
    const init = async () => {
      connectWithSocketServer();

      socket.on("connect", async () => {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: true,
          audio: true,
        });

        cameraStreamRef.current = stream;
        localCamRef.current.srcObject = stream;

        const peer = new RTCPeerConnection();

        stream.getTracks().forEach((track) => {
          peer.addTrack(track, stream);
        });

        peer.ontrack = ({ streams: [remoteStream] }) => {
          remoteVideoRef.current.srcObject = remoteStream;
        };

        peer.onicecandidate = (event) => {
          if (event.candidate) {
            socket.emit("ice-candidate", {
              candidate: event.candidate,
              to: serverId,
            });
          }
        };

        peerConnectionRef.current = peer;

        joinRoom({ roomId: serverId });

        socket.on("user-joined", async () => {
          setIsInitiator(true);
          const offer = await peer.createOffer();
          await peer.setLocalDescription(offer);
          socket.emit("offer", { offer, roomId: serverId });
        });

        socket.on("offer", async ({ offer, from }) => {
          if (!isInitiator) {
            await peer.setRemoteDescription(new RTCSessionDescription(offer));
            const answer = await peer.createAnswer();
            await peer.setLocalDescription(answer);
            socket.emit("answer", { answer, to: from });
          }
        });

        socket.on("answer", async ({ answer }) => {
          await peer.setRemoteDescription(new RTCSessionDescription(answer));
        });

        socket.on("ice-candidate", async ({ candidate }) => {
          try {
            await peer.addIceCandidate(new RTCIceCandidate(candidate));
          } catch (err) {
            console.error("ICE error", err);
          }
        });

        socket.on("chat-message", (msg) => {
          setMessages((prev) => [...prev, msg]);
        });
      });
    };

    init();

    return () => {
      leaveRoom();
    };
  }, [serverId]);

  const sendMessage = () => {
    if (input.trim()) {
      socket.emit("chat-message", input);
      setMessages((prev) => [...prev, input]);
      setInput("");
    }
  };

  const toggleMic = () => {
    const track = cameraStreamRef.current?.getAudioTracks?.()[0];
    if (track) {
      track.enabled = !track.enabled;
      setMicEnabled(track.enabled);
    }
  };

  const toggleCam = () => {
    const track = cameraStreamRef.current?.getVideoTracks?.()[0];
    if (track) {
      track.enabled = !track.enabled;
      setCamEnabled(track.enabled);
    }
  };

  const shareScreen = async () => {
    if (isSharingScreen) {
      screenStreamRef.current?.getTracks().forEach((t) => t.stop());
      setIsSharingScreen(false);
      localScreenRef.current.srcObject = null;
      return;
    }

    try {
      const screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
      screenStreamRef.current = screenStream;
      localScreenRef.current.srcObject = screenStream;

      screenStream.getTracks().forEach((track) => {
        peerConnectionRef.current.addTrack(track, screenStream);
        track.onended = () => shareScreen(); // auto-stop
      });

      setIsSharingScreen(true);
    } catch (e) {
      console.error("Screen share error:", e);
    }
  };

  const sendReaction = (emoji) => {
    const id = Math.random().toString(36).substring(2);
    setReactions((prev) => [...prev, { id, emoji }]);
    setTimeout(() => {
      setReactions((prev) => prev.filter((r) => r.id !== id));
    }, 2000);
  };

  const leaveRoom = () => {
    cameraStreamRef.current?.getTracks().forEach((track) => track.stop());
    screenStreamRef.current?.getTracks().forEach((track) => track.stop());
    peerConnectionRef.current?.close();
    peerConnectionRef.current = null;
    leaveSocketRoom({ roomId: serverId });
    socket.off();
    navigate("/");
  };

  const styles = {
    container: {
      display: "flex",
      flexDirection: "column",
      height: "100vh",
      backgroundColor: "#1e1e1e",
      color: "#fff",
    },
    videoSection: {
      display: "flex",
      flexWrap: "wrap",
      justifyContent: "center",
      gap: "1rem",
      padding: "1rem",
      flex: 1,
    },
    video: {
      width: "300px",
      height: "200px",
      backgroundColor: "#000",
      borderRadius: "10px",
      objectFit: "cover",
    },
    chatSection: {
      display: "flex",
      flexDirection: "column",
      backgroundColor: "#2a2a2a",
      padding: "0.5rem",
      height: "200px",
      overflow: "hidden",
    },
    messages: {
      flex: 1,
      overflowY: "auto",
      padding: "0.5rem",
    },
    message: {
      marginBottom: "0.25rem",
    },
    inputArea: {
      display: "flex",
      alignItems: "center",
      marginTop: "0.5rem",
    },
    input: {
      flex: 1,
      padding: "0.5rem",
      marginRight: "0.5rem",
      borderRadius: "5px",
      border: "none",
    },
    sendButton: {
      padding: "0.5rem 1rem",
      backgroundColor: "#4caf50",
      border: "none",
      borderRadius: "5px",
      cursor: "pointer",
      color: "#fff",
    },
    controls: {
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      padding: "1rem",
      gap: "0.5rem",
    },
    controlButton: {
      fontSize: "1.5rem",
      backgroundColor: "#333",
      border: "none",
      borderRadius: "50%",
      width: "40px",
      height: "40px",
      color: "#fff",
      cursor: "pointer",
    },
    leaveButton: {
      padding: "0.5rem 1rem",
      backgroundColor: "#f44336",
      color: "#fff",
      border: "none",
      borderRadius: "5px",
      cursor: "pointer",
      marginLeft: "1rem",
    },
    emojiStyle: (index) => ({
      position: "absolute",
      fontSize: "2rem",
      top: `${50 + Math.random() * 30}%`,
      left: `${10 + index * 10}%`,
      animation: "floatUp 2s ease-out",
      pointerEvents: "none",
    }),
    emojiKeyframes: `
      @keyframes floatUp {
        0% { transform: translateY(0); opacity: 1; }
        100% { transform: translateY(-50px); opacity: 0; }
      }
    `,
  };

  return (
    <>
      <style>{styles.emojiKeyframes}</style>
      <div style={styles.container}>
        <div style={styles.videoSection}>
          <video ref={localCamRef} autoPlay muted style={styles.video} />
          <video ref={localScreenRef} autoPlay muted style={styles.video} />
          <video ref={remoteVideoRef} autoPlay style={styles.video} />
          {reactions.map((r, i) => (
            <div key={r.id} style={styles.emojiStyle(i)}>{r.emoji}</div>
          ))}
        </div>

        <div style={styles.chatSection}>
          <div style={styles.messages}>
            {messages.map((msg, idx) => (
              <div key={idx} style={styles.message}>{msg}</div>
            ))}
          </div>
          <div style={styles.inputArea}>
            <input
              style={styles.input}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && sendMessage()}
              placeholder="Type a message..."
            />
            <button style={styles.sendButton} onClick={sendMessage}>Send</button>
          </div>
        </div>

        <div style={styles.controls}>
          <button style={styles.controlButton} onClick={toggleCam}>
            {camEnabled ? "🎥" : "🚫"}
          </button>
          <button style={styles.controlButton} onClick={toggleMic}>
            {micEnabled ? "🎙️" : "🔇"}
          </button>
          <button style={styles.controlButton} onClick={shareScreen}>
            {isSharingScreen ? "❌" : "🖥️"}
          </button>
          {emojis.map((e, i) => (
            <button key={i} style={styles.controlButton} onClick={() => sendReaction(e)}>
              {e}
            </button>
          ))}
          <button style={styles.leaveButton} onClick={leaveRoom}>Leave</button>
        </div>
      </div>
    </>
  );
};

export default StreamRoom;
